from flask import Flask, render_template, redirect, url_for, request, send_file
import sqlite3
from docxtpl import DocxTemplate
import os
import datetime

app = Flask(__name__)


# Функции для работы с базой данных
def get_services_from_db():
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Services")
    services = cursor.fetchall()
    conn.close()
    return services


def get_service_from_db(service_id):
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Services WHERE id = ?", (service_id,))
    service = cursor.fetchone()
    conn.close()
    return service


def get_patients_from_db():
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Patients")
    patients = cursor.fetchall()
    conn.close()
    return patients


def get_patient_from_db(patient_id):
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Patients WHERE id = ?", (patient_id,))
    patient = cursor.fetchone()
    conn.close()
    return patient


def get_patient_with_visits_from_db(patient_id):
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute("""
        SELECT 
            p.id,
            p.FIO,
            p.DateOfBirth,
            p.PhoneNumber,
            p.Address,
            p.InsurancePolicy,
            a.Date,
            a.Time,
            e.FIO,
            a.Complaints,
            a.PreliminaryDiagnosis
        FROM Patients p
        LEFT JOIN Appointments a ON p.id = a.id_patient
        LEFT JOIN Employees e ON a.id_doctor = e.id
        WHERE p.id = ?
    """, (patient_id,))
    visits = cursor.fetchall()
    conn.close()

    if not visits:
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Patients WHERE id = ?", (patient_id,))
        patient = cursor.fetchone()
        conn.close()
        if patient:
            return [patient + (None, None, None, None, None,)]
        else:
            return None

    return visits


def get_employees_from_db():
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Employees")
    employees = cursor.fetchall()
    conn.close()
    return employees


def get_employee_from_db(employee_id):
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Employees WHERE id = ?", (employee_id,))
    employee = cursor.fetchone()
    conn.close()
    return employee


def get_appointments_from_db():
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute(
        "SELECT Appointments.id, Appointments.Date, Appointments.Time, Employees.FIO, Patients.FIO FROM Appointments JOIN Employees ON Appointments.id_doctor = Employees.id JOIN Patients ON Appointments.id_patient = Patients.id")
    appointments = cursor.fetchall()
    conn.close()
    return appointments


def get_appointment_from_db(appointment_id):
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute(
        "SELECT Appointments.id, Appointments.Date, Appointments.Time, Employees.FIO, Patients.FIO FROM Appointments JOIN Employees ON Appointments.id_doctor = Employees.id JOIN Patients ON Appointments.id_patient = Patients.id WHERE Appointments.id = ?",
        (appointment_id,))
    appointment = cursor.fetchone()
    conn.close()
    return appointment


def get_payments_from_db():
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute(
        "SELECT Payments.id, Payments.Date, Payments.payment_time, Patients.FIO, Services.Name, Payments.Summ, Employees.FIO, Services.Code FROM Payments JOIN Patients ON Payments.id_patient = Patients.id JOIN Services ON Payments.id_service = Services.id JOIN Employees ON Payments.employee_id = Employees.id")
    payments = cursor.fetchall()
    conn.close()
    return payments


def get_payment_from_db(payment_id):
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute(
        "SELECT Payments.id, Payments.Date, Payments.payment_time, Patients.FIO, Services.Name, Payments.Summ, Employees.FIO, Services.Code FROM Payments JOIN Patients ON Payments.id_patient = Patients.id JOIN Services ON Payments.id_service = Services.id JOIN Employees ON Payments.employee_id = Employees.id WHERE Payments.id = ?",
        (payment_id,))
    payment = cursor.fetchone()
    conn.close()
    return payment


def get_clinic_info():
    conn = sqlite3.connect('stomatologclinic.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM ClinicInfo")
    clinic_info = cursor.fetchone()
    conn.close()
    return clinic_info


def generate_payment_check(payment_data, clinic_info):
    template_path = 'templates/documents/cheque.docx'
    template = DocxTemplate(template_path)

    if payment_data:
        service = get_service_from_db(payment_data[2])
        context = {
            'CLINIC_NAME': clinic_info[1] if clinic_info else "Неизвестно",
            'CLINIC_ADDRESS': clinic_info[2] if clinic_info else "Неизвестно",
            'CLINIC_PHONE': clinic_info[3] if clinic_info else "Неизвестно",
            'CHECK_NUMBER': payment_data[0] if payment_data else "Неизвестно",
            'PAYMENT_DATE': payment_data[1] if payment_data else "Неизвестно",
            'PAYMENT_TIME': payment_data[2] if payment_data else "Неизвестно",
            'PATIENT_FULLNAME': payment_data[3] if payment_data else "Неизвестно",
            'PATIENT_ID': payment_data[0] if payment_data else "Неизвестно",
            'SERVICE_NAME': payment_data[4] if payment_data else "Неизвестно",
            'SERVICE_CODE': service[2] if service else "Неизвестно",
            'SERVICE_COST': payment_data[5] if payment_data else "Неизвестно",
            'EMPLOYEE_NAME': payment_data[6] if payment_data else "Неизвестно"
        }
    else:
        context = {
            'CLINIC_NAME': None,
            'CLINIC_ADDRESS': None,
            'CLINIC_PHONE': None,
            'CHECK_NUMBER': None,
            'PAYMENT_DATE': None,
            'PAYMENT_TIME': None,
            'PATIENT_FULLNAME': None,
            'PATIENT_ID': None,
            'SERVICE_NAME': None,
            'SERVICE_CODE': None,
            'SERVICE_COST': None,
            'EMPLOYEE_NAME': None
        }
    output_path = f'templates/documents/payment_{payment_data[0] if payment_data else "unknown"}_cheque.docx'
    template.render(context)
    template.save(output_path)
    return output_path


@app.route('/generate_payment_check/<int:payment_id>')
def generate_payment_check_page(payment_id):
    payment_data = get_payment_from_db(payment_id)
    clinic_info = get_clinic_info()
    print(f"payment_data: {payment_data}")  # Добавьте эту строку
    if not payment_data:
        return render_template('404.html'), 404
    output_path = generate_payment_check(payment_data, clinic_info)
    return send_file(output_path, as_attachment=True, download_name=f'payment_{payment_id}cheque.docx')


@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404


# Маршруты
@app.route('/')
def index():
    return redirect(url_for('patients_list'))  # Перенаправление на список пациентов


@app.route('/patients')
def patients_list():
    patients = get_patients_from_db()
    return render_template('patients/patients_list.html', patients=patients)


@app.route('/patients/<int:id>')
def patient_details(id):
    patient_data = get_patient_with_visits_from_db(id)
    if patient_data:
        # Проверка типа patient_data
        print(f"Тип patient_data: {type(patient_data)}")

        # Исправление: Проверка, является ли patient_data словарем
        if isinstance(patient_data, dict):
            return render_template('patients/patient_details.html', patient=patient_data, visits=patient_data['visits'])
        else:
            # Обработка ошибки: patient_data не является словарем
            print("ОШИБКА: patient_data не является словарем!")
            print(f"Содержимое patient_data: {patient_data}") # Выводим содержимое для диагностики
            return "Internal Server Error", 500 # Возвращаем ошибку 500

    else:
        return render_template('patients/patient_details.html', patient=None, visits=None)


@app.route('/patients/<int:id>/edit', methods=['GET', 'POST'])
def edit_patient(id):
    patient = get_patient_from_db(id)
    if request.method == 'POST':
        fio = request.form['fio']
        date_of_birth = request.form['date_of_birth']
        phone = request.form['phone']
        address = request.form['address']
        insurance_policy = request.form['insurance_policy']
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE Patients SET FIO = ?, DateOfBirth = ?, PhoneNumber = ?, Address = ?, InsurancePolicy = ? WHERE id = ?",
            (fio, date_of_birth, phone, address, insurance_policy, id))
        conn.commit()
        conn.close()
        return redirect(url_for('patient_details', id=id))
    return render_template('patients/edit_patient.html', patient=patient)


@app.route('/employees')
def employees_list():
    employees = get_employees_from_db()
    return render_template('employees/employees_list.html', employees=employees)


@app.route('/employees/<int:id>')
def employee_details(id):
    employee = get_employee_from_db(id)
    return render_template('employees/employee_details.html', employee=employee)


@app.route('/employees/<int:id>/edit', methods=['GET', 'POST'])
def edit_employee(id):
    employee = get_employee_from_db(id)
    if request.method == 'POST':
        fio = request.form['fio']
        position = request.form['position']
        phone = request.form['phone']
        specialization = request.form['specialization']
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute("UPDATE Employees SET FIO = ?, Position = ?, PhoneNumber = ?, Specialization = ? WHERE id = ?",
                       (fio, position, phone, specialization, id))
        conn.commit()
        conn.close()
        return redirect(url_for('employee_details', id=id))
    return render_template('employees/edit_employee.html', employee=employee)


@app.route('/services')
def services_list():
    services = get_services_from_db()
    return render_template('services/services_list.html', services=services)


@app.route('/services/<int:id>')
def service_details(id):
    service = get_service_from_db(id)
    return render_template('services/service_details.html', service=service)


@app.route('/services/<int:id>/edit', methods=['GET', 'POST'])
def edit_service(id):
    service = get_service_from_db(id)
    if request.method == 'POST':
        name = request.form['name']
        code = request.form['code']
        cost = request.form['cost']
        description = request.form['description']
        detailed_description = request.form['detailed_description']
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE Services SET Name = ?, Code = ?, Cost = ?, Description = ?, DetailedDescription = ? WHERE id = ?",
            (name, code, cost, description, detailed_description, id))
        conn.commit()
        conn.close()
        return redirect(url_for('service_details', id=id))
    return render_template('services/edit_service.html', service=service)


@app.route('/appointments')
def appointments_list():
    appointments = get_appointments_from_db()
    return render_template('appointments/appointments_list.html', appointments=appointments)


@app.route('/appointments/<int:id>')
def appointment_details(id):
    appointment = get_appointment_from_db(id)
    return render_template('appointments/appointment_details.html', appointment=appointment)


@app.route('/appointments/<int:id>/edit', methods=['GET', 'POST'])
def edit_appointment(id):
    appointment = get_appointment_from_db(id)
    employees = get_employees_from_db()
    patients = get_patients_from_db()
    if request.method == 'POST':
        date = request.form['date']
        time = request.form['time']
        doctor = request.form['doctor']
        patient = request.form['patient']
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE Appointments SET id_doctor = ?, id_patient = ?, Date = ?, Time = ? WHERE id = ?",
            (doctor, patient, date, time, id))
        conn.commit()
        conn.close()
        return redirect(url_for('appointment_details', id=id))
    return render_template('appointments/edit_appointment.html', appointment=appointment, employees=employees,
                           patients=patients)


@app.route('/payments')
def payments_list():
    payments = get_payments_from_db()
    return render_template('payments/payments_list.html', payments=payments)


@app.route('/payments/<int:id>')
def payment_details(id):
    payment = get_payment_from_db(id)
    return render_template('payments/payment_details.html', payment=payment)


@app.route('/payments/<int:id>/edit', methods=['GET', 'POST'])
def edit_payment(id):
    payment = get_payment_from_db(id)
    services = get_services_from_db()
    patients = get_patients_from_db()
    employees = get_employees_from_db()
    if request.method == 'POST':
        date = request.form['date']
        payment_time = request.form['time']
        patient = request.form['patient']
        service = request.form['service']
        summ = request.form['summ']
        employee = request.form['employee']
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE Payments SET id_patient = ?, id_service = ?, Date = ?, Summ = ?, payment_time = ?, employee_id = ? WHERE id = ?",
            (patient, service, date, summ, payment_time, employee, id))
        conn.commit()
        conn.close()
        return redirect(url_for('payment_details', id=id))
    return render_template('payments/edit_payment.html', payment=payment, services=services, patients=patients,
                           employees=employees)


@app.route('/add_patient', methods=['GET', 'POST'])
def add_patient():
    if request.method == 'POST':
        fio = request.form['fio']
        date_of_birth = request.form['date_of_birth']
        phone = request.form['phone']
        address = request.form['address']
        insurance_policy = request.form['insurance_policy']
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO Patients (FIO, DateOfBirth, PhoneNumber, Address, InsurancePolicy) VALUES (?, ?, ?, ?, ?)",
            (fio, date_of_birth, phone, address, insurance_policy))
        conn.commit()
        conn.close()
        return redirect(url_for('patients_list'))
    return render_template('patients/add_patient.html')


@app.route('/add_employee', methods=['GET', 'POST'])
def add_employee():
    if request.method == 'POST':
        fio = request.form['fio']
        position = request.form['position']
        phone = request.form['phone']
        specialization = request.form['specialization']
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO Employees (FIO, Position, PhoneNumber, Specialization) VALUES (?, ?, ?, ?)",
                       (fio, position, phone, specialization))
        conn.commit()
        conn.close()
        return redirect(url_for('employees_list'))
    return render_template('employees/add_employee.html')


@app.route('/add_service', methods=['GET', 'POST'])
def add_service():
    if request.method == 'POST':
        name = request.form['name']
        code = request.form['code']
        cost = request.form['cost']
        description = request.form['description']
        detailed_description = request.form['detailed_description']
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO Services (Name, Code, Cost, Description, DetailedDescription) VALUES (?, ?, ?, ?, ?)",
            (name, code, cost, description, detailed_description))
        conn.commit()
        conn.close()
        return redirect(url_for('services_list'))
    return render_template('services/add_service.html')


@app.route('/add_appointment', methods=['GET', 'POST'])
def add_appointment():
    employees = get_employees_from_db()
    patients = get_patients_from_db()
    if request.method == 'POST':
        date = request.form['date']
        time = request.form['time']
        doctor = request.form['doctor']
        patient = request.form['patient']
        complaints = request.form['complaints']
        preliminary_diagnosis = request.form['preliminary_diagnosis']
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO Appointments (id_doctor, id_patient, Date, Time, Complaints, PreliminaryDiagnosis) VALUES (?, ?, ?, ?, ?, ?)",
            (doctor, patient, date, time, complaints, preliminary_diagnosis))
        conn.commit()
        conn.close()
        return redirect(url_for('appointments_list'))
    return render_template('appointments/add_appointment.html', employees=employees, patients=patients)


@app.route('/add_payment', methods=['GET', 'POST'])
def add_payment():
    services = get_services_from_db()
    patients = get_patients_from_db()
    employees = get_employees_from_db()
    if request.method == 'POST':
        date = request.form['date']
        payment_time = request.form['time']
        patient = request.form['patient']
        service = request.form['service']
        summ = request.form['summ']
        employee = request.form['employee']
        conn = sqlite3.connect('stomatologclinic.db')
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO Payments (id_patient, id_service, Date, Summ, payment_time, employee_id) VALUES (?, ?, ?, ?, ?, ?)",
            (patient, service, date, summ, payment_time, employee))
        conn.commit()
        conn.close()
        return redirect(url_for('payments_list'))
    return render_template('payments/add_payment.html', services=services, patients=patients, employees=employees)


@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404


if __name__ == '__main__':
    app.run(debug=True)