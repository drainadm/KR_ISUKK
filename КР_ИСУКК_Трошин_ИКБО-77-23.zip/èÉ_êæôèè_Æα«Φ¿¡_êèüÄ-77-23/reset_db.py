import sqlite3

def reset_database(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()

    # Удаление таблиц (если они есть)
    cursor.execute("DROP TABLE IF EXISTS Patients;")
    cursor.execute("DROP TABLE IF EXISTS Employees;")
    cursor.execute("DROP TABLE IF EXISTS Services;")
    cursor.execute("DROP TABLE IF EXISTS Appointments;")
    cursor.execute("DROP TABLE IF EXISTS Payments;")
    cursor.execute("DROP TABLE IF EXISTS ClinicInfo;")

    # Создание таблиц (код остается без изменений)
    cursor.execute('''
        CREATE TABLE Patients (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            FIO TEXT NOT NULL,
            DateOfBirth DATE,
            PhoneNumber TEXT,
            Address TEXT,
            InsurancePolicy TEXT
        );
    ''')

    cursor.execute('''
        CREATE TABLE Employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            FIO TEXT NOT NULL,
            Position TEXT NOT NULL,
            PhoneNumber TEXT,
            Specialization TEXT
        );
    ''')

    cursor.execute('''
        CREATE TABLE Services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            Name TEXT NOT NULL,
            Code TEXT UNIQUE,
            Cost REAL NOT NULL,
            Description TEXT,
            DetailedDescription TEXT
        );
    ''')

    cursor.execute('''
        CREATE TABLE Appointments (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
            id_doctor INTEGER NOT NULL,
            id_patient INTEGER NOT NULL,
            Date DATE NOT NULL,
            Time TIME NOT NULL,
            Complaints TEXT,
            PreliminaryDiagnosis TEXT,
            FOREIGN KEY (id_doctor) REFERENCES Employees(id),
            FOREIGN KEY (id_patient) REFERENCES Patients(id)
        );
    ''')

    cursor.execute('''
        CREATE TABLE Payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            id_patient INTEGER NOT NULL,
            id_service INTEGER NOT NULL,
            Date DATE NOT NULL,
            Summ REAL NOT NULL,
            payment_time TEXT,
            employee_id INTEGER,
            FOREIGN KEY (id_patient) REFERENCES Patients(id),
            FOREIGN KEY (id_service) REFERENCES Services(id),
             FOREIGN KEY (employee_id) REFERENCES Employees(id)
         );
    ''')
    cursor.execute('''
    CREATE TABLE ClinicInfo (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        Name TEXT NOT NULL,
        Address TEXT NOT NULL,
        PhoneNumber TEXT NOT NULL
    );
    ''')

    # Добавление начальных данных (с изменениями под стоматологию)
    cursor.execute(
        "INSERT INTO Patients (FIO, DateOfBirth, PhoneNumber, Address, InsurancePolicy) VALUES (?, ?, ?, ?, ?)",
        ("Иванов Иван Иванович", "1985-03-10", "+79031234567", "ул. Стоматологическая, д. 5", "СМС123456789"))
    cursor.execute(
        "INSERT INTO Patients (FIO, DateOfBirth, PhoneNumber, Address, InsurancePolicy) VALUES (?, ?, ?, ?, ?)",
        ("Петрова Елена Васильевна", "1992-11-25", "+79169876543", "пр. Зубной, д. 12", "ДМС987654321"))
    cursor.execute(
        "INSERT INTO Patients (FIO, DateOfBirth, PhoneNumber, Address, InsurancePolicy) VALUES (?, ?, ?, ?, ?)",
        ("Сидоров Алексей Петрович", "1978-06-01", "+79261112233", "пер. Кариесный, д. 3", "ОМС456789123"))

    cursor.execute("INSERT INTO Employees (FIO, Position, PhoneNumber, Specialization) VALUES (?, ?, ?, ?)",
                   ("Смирнов Дмитрий Андреевич", "Стоматолог-терапевт", "+79257778899", "Лечение кариеса, пульпита"))
    cursor.execute("INSERT INTO Employees (FIO, Position, PhoneNumber, Specialization) VALUES (?, ?, ?, ?)",
                   ("Кузнецова Ольга Ивановна", "Стоматолог-хирург", "+79153334455", "Удаление зубов, имплантация"))
    cursor.execute("INSERT INTO Employees (FIO, Position, PhoneNumber, Specialization) VALUES (?, ?, ?, ?)",
                   ("Волкова Анастасия Сергеевна", "Ассистент стоматолога", "+79055556677", "Ассистирование на приеме"))

    cursor.execute("INSERT INTO Services (Name, Code, Cost, Description, DetailedDescription) VALUES (?, ?, ?, ?, ?)",
                   ("Осмотр и консультация", "CONS", 1000, "Первичный осмотр", "Осмотр полости рта, консультация по лечению"))
    cursor.execute("INSERT INTO Services (Name, Code, Cost, Description, DetailedDescription) VALUES (?, ?, ?, ?, ?)",
                   ("Лечение кариеса", "CARIES", 3500, "Лечение кариеса", "Препарирование кариозной полости, пломбирование"))
    cursor.execute("INSERT INTO Services (Name, Code, Cost, Description, DetailedDescription) VALUES (?, ?, ?, ?, ?)",
                   ("Удаление зуба", "EXTRACT", 2000, "Удаление зуба", "Удаление зуба любой сложности"))
    cursor.execute("INSERT INTO Services (Name, Code, Cost, Description, DetailedDescription) VALUES (?, ?, ?, ?, ?)",
                   ("Профессиональная чистка зубов", "CLEAN", 4000, "Чистка зубов", "Удаление зубного камня и налета"))

    cursor.execute(
        "INSERT INTO Appointments (id_doctor, id_patient, Date, Time, Complaints, PreliminaryDiagnosis) VALUES (?, ?, ?, ?, ?, ?)",
        (1, 1, "2024-03-15", "11:00", "Болит зуб", "Кариес?"))
    cursor.execute(
        "INSERT INTO Appointments (id_doctor, id_patient, Date, Time, Complaints, PreliminaryDiagnosis) VALUES (?, ?, ?, ?, ?, ?)",
        (2, 2, "2024-03-18", "15:00", "Необходимо удалить зуб мудрости", "Ретинированный зуб?"))
    cursor.execute(
        "INSERT INTO Appointments (id_doctor, id_patient, Date, Time, Complaints, PreliminaryDiagnosis) VALUES (?, ?, ?, ?, ?, ?)",
        (1, 3, "2024-03-20", "09:30", "Кровоточивость десен", "Гингивит?"))

    cursor.execute(
        "INSERT INTO Payments (id_patient, id_service, Date, Summ, payment_time, employee_id) VALUES (?, ?, ?, ?, ?, ?)",
        (1, 2, "2024-03-15", 3500, "11:30", 3))
    cursor.execute(
        "INSERT INTO Payments (id_patient, id_service, Date, Summ, payment_time, employee_id) VALUES (?, ?, ?, ?, ?, ?)",
        (2, 3, "2024-03-18", 2000, "15:30", 3))
    cursor.execute(
        "INSERT INTO Payments (id_patient, id_service, Date, Summ, payment_time, employee_id) VALUES (?, ?, ?, ?, ?, ?)",
        (3, 4, "2024-03-20", 4000, "10:00", 3))

    cursor.execute("INSERT INTO ClinicInfo (Name, Address, PhoneNumber) VALUES (?, ?, ?)",
                   ("Стоматологическая клиника 'Белые зубы'", "ул. Здоровая улыбка, д. 7", "+74997654321"))

    conn.commit()
    conn.close()
    print("Database reset successfully.")


if __name__ == '__main__':
    db_file = 'stomatologclinic.db'  # Имя вашей базы данных
    reset_database(db_file)